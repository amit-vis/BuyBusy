You and your friend are building a simple E-Commerce site. You asked your friend to work on the products list, while you were working on the main page. As soon as the page is completed, you find that your and your friend's style has gotten mixed up.

So, you decide to refactor the styles and use a different approach to resolve this issue.

Fix the styles so that your output matches the expected output.

Expected Output: <img src="https://res.cloudinary.com/dl26pbek4/image/upload/v1672995191/cn-questions/Capture1_bn53ly.png">
